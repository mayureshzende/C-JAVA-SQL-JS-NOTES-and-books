package com.pga;

//Functional code
public class StudentCRUD {
  public void addStudent() {
	  System.out.println("Adding student");
  }
  public void deleteStudent() {
	  System.out.println("Deleting student");
  }
  public void updateStudent() {
	  System.out.println("Updating student");
  }

}
