function getValue(id) {
 return document.getElementById(id).value;
}
