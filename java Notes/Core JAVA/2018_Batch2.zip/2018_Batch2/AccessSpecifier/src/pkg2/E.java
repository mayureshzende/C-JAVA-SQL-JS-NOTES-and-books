package pkg2;
import pkg1.A;
public class E {
	public static void main(String[] args) {
		 A obj = new A();
		 System.out.println("public:" + obj.d);

	}
}
