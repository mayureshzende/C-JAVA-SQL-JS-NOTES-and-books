public class B {
  public static void main(String[] args) {
  	System.out.println("Public class scenario");
  }
}
//javac Test.java
//java B