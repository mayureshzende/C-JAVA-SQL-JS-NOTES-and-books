class Puzzle1 {
 public static void main(String[] args) {
   System.out.println("PGA"+1+2+"Java");//PGA12Java
   System.out.println(1+2+"PGA"+3+4);//3PGA34
   System.out.println("PGA"+1+2);//PGA12
   System.out.println("PGA"+(1+2));//PGA3
 }
}