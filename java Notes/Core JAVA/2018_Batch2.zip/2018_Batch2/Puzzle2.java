class Puzzle2 {
  public static void main(String[] args) {
  	System.out.println(10+010+0X10+0b10);//36
  	System.out.println(045+0X2B+0b101101);//125
  }
}