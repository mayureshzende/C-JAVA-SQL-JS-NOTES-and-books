class DataTypeTest {
 public static void main(String[] args) {
 	char ch = 'A';
 	double s = ch;
 }
}