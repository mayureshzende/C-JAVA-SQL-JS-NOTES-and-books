import com.pga.stats.Average;

public class Test {
	public static void main(String[] args) {
		Average obj = new Average();
		System.out.println(obj.avg(3, 11));
	}
}
