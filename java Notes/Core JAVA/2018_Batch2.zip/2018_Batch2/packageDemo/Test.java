import com.pga.stats.Average;

class Test {
	public static void main(String args[]) {
		int a =10, b = 20;
		Average obj = new Average();
		System.out.println(obj.avg(a,b));
	}
}